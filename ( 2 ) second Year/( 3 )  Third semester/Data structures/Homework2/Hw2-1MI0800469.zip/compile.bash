#!/bin/bash

g++ ./src/*.cpp ./src/Implementation/*.cpp -o ./bin/a.out

cd ./bin

./a.out